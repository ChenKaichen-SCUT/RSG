; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun p () Int)
(assert
 (let (($x16 (= p 1)))
 (let (($x21 (and $x16 (>= x 3) (<= x 4))))
 (let (($x35 (or (and (= p 0) (>= x 0) (<= x 1)) $x21)))
 (let (($x126 (and (and (>= 3 (- (- p x))) (>= 1 p)) (<= (- x) (- 4)))))
 (let (($x118 (and (and (>= 0 (- x)) (>= 0 (+ p x))) (>= 0 (- p)))))
 (let (($x127 (or $x118 $x126)))
 (xor $x127 $x35))))))))
(check-sat)
